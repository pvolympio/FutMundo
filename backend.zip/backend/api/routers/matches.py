"""
Matches API Router.
Endpoints for match-related operations.
"""

import logging
from typing import Annotated

import asyncpg
from fastapi import APIRouter, Depends, Path

from backend.api.database import get_database, call_match_details
from backend.api.dependencies import not_found_error

router = APIRouter(
    prefix="/matches",
    tags=["Matches"],
    responses={404: {"description": "Not found"}},
)

logger = logging.getLogger(__name__)


@router.get(
    "/{match_id}",
    response_model=dict,
    summary="Get match details",
    description="Get complete match details including lineups, timeline, statistics, odds, and officials.",
    responses={
        200: {"description": "Match details retrieved successfully"},
        404: {"description": "Match not found"},
    },
)
async def get_match_details(
    match_id: Annotated[int, Path(..., description="Match ID")],
    db: asyncpg.Connection = Depends(get_database),
):
    """Get complete match details from fn_api_match_details RPC function."""
    logger.info("Getting details for match_id=%s", match_id)

    result = await call_match_details(db, match_id)

    if result is None:
        raise not_found_error("Match")

    return result