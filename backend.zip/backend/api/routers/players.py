"""
Players API Router.
Endpoints for player-related operations.
"""

import logging
from typing import Annotated

import asyncpg
from fastapi import APIRouter, Depends, Path

from backend.api.database import get_database, call_player_profile
from backend.api.dependencies import not_found_error

router = APIRouter(
    prefix="/players",
    tags=["Players"],
    responses={404: {"description": "Not found"}},
)

logger = logging.getLogger(__name__)


@router.get(
    "/{player_id}",
    response_model=dict,
    summary="Get player profile",
    description="Get complete player profile including current club, market value history, "
                "career teams, injuries, and current season statistics.",
    responses={
        200: {"description": "Player profile retrieved successfully"},
        404: {"description": "Player not found"},
    },
)
async def get_player_profile(
    player_id: Annotated[int, Path(..., description="Player ID")],
    db: asyncpg.Connection = Depends(get_database),
):
    """Get complete player profile from fn_api_player_profile RPC function."""
    logger.info("Getting profile for player_id=%s", player_id)

    result = await call_player_profile(db, player_id)

    if result is None:
        raise not_found_error("Player")

    return result