"""
Teams API Router.
Endpoints for team-related operations.
"""

import logging
from typing import Annotated

import asyncpg
from fastapi import APIRouter, Depends, Query, Path

from backend.api.dependencies import not_found_error
from backend.api.models import HeadToHeadResponse, TeamProfile
from backend.api.database import get_database, call_team_profile, call_team_head_to_head

router = APIRouter(
    prefix="/teams",
    tags=["Teams"],
    responses={404: {"description": "Not found"}},
)

logger = logging.getLogger(__name__)


@router.get(
    "/{team_id}",
    response_model=TeamProfile,
    summary="Get team profile",
    description="Get complete team profile including squad, manager, form, and recent matches.",
    responses={
        200: {"description": "Team profile retrieved successfully"},
        404: {"description": "Team not found"},
    },
)
async def get_team_profile(
    team_id: Annotated[int, Path(..., description="Team ID")],
    season_id: int | None = Query(None, description="Season ID (optional)"),
    db: asyncpg.Connection = Depends(get_database),
):
    """Get complete team profile from fn_api_team_profile RPC function."""
    logger.info("Getting profile for team_id=%s, season_id=%s", team_id, season_id)

    result = await call_team_profile(db, team_id, season_id)

    if result is None:
        raise not_found_error("Team")

    return result


@router.get(
    "/{team_id}/head-to-head/{team_b_id}",
    response_model=HeadToHeadResponse,
    summary="Head-to-head between teams",
    description="Get head-to-head statistics between two teams including recent matches.",
    responses={
        200: {"description": "Head-to-head data retrieved successfully"},
        404: {"description": "Team not found"},
    },
)
async def get_head_to_head(
    team_id: Annotated[int, Path(..., description="First team ID (team A)")],
    team_b_id: Annotated[int, Path(..., description="Second team ID (team B)")],
    limit: int = Query(10, ge=1, le=100, description="Number of recent matches to return"),
    db: asyncpg.Connection = Depends(get_database),
):
    """Get head-to-head statistics between two teams using fn_team_head_to_head RPC function."""
    logger.info("Getting H2H for team_a=%s, team_b=%s, limit=%s", team_id, team_b_id, limit)

    result = await call_team_head_to_head(db, team_id, team_b_id, limit)

    if result is None:
        raise not_found_error("Team comparison")

    return result