"""
Main FastAPI Application for FUTFUT API.

A professional API for consuming FUTFUT database data.
Provides endpoints for teams, players, matches, search, and standings.
"""

import logging
import sys

import uvicorn
from fastapi import FastAPI

from backend.api.config import settings
from backend.api.routers import (
    teams_router,
    players_router,
    matches_router,
    search_router,
    standings_router,
)
from backend.api.database import db_pool, close_application_connections
from backend.api.middleware import register_middleware

# Configure logging
logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
    ],
)

logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title=settings.PROJECT_NAME,
        version=settings.API_VERSION,
        description=settings.API_DESCRIPTION,
        debug=settings.DEBUG,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        # Contact information
        contact={
            "name": "FUTFUT API Team",
            "url": "https://github.com/futfut",
        },
        # License
        license_info={
            "name": "MIT",
            "url": "https://opensource.org/licenses/MIT",
        },
    )

    # Register middleware
    register_middleware(app)

    # Include routers
    app.include_router(teams_router)
    app.include_router(players_router)
    app.include_router(matches_router)
    app.include_router(search_router)
    app.include_router(standings_router)

    # Health check endpoint
    @app.get("/health", tags=["Health"], summary="Health check")
    async def health_check():
        """Health check endpoint to verify API is running."""
        return {"status": "healthy", "version": settings.API_VERSION}

    # Root endpoint
    @app.get("/", tags=["Root"], summary="API info")
    async def root():
        """Root endpoint with API information."""
        return {
            "name": settings.PROJECT_NAME,
            "version": settings.API_VERSION,
            "description": settings.API_DESCRIPTION,
            "endpoints": {
                "teams": "/teams",
                "players": "/players",
                "matches": "/matches",
                "search": "/search",
                "standings": "/standings",
            },
        }

    # Startup and shutdown events
    @app.on_event("startup")
    async def startup_event():
        """Initialize application on startup."""
        logger.info("Starting %s v%s", settings.PROJECT_NAME, settings.API_VERSION)
        await db_pool.initialize()

    @app.on_event("shutdown")
    async def shutdown_event():
        """Cleanup on application shutdown."""
        logger.info("Shutting down application")
        await close_application_connections()

    return app


# Create the application instance
app = create_app()


if __name__ == "__main__":
    uvicorn.run(
        "api.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level="debug" if settings.DEBUG else "info",
    )